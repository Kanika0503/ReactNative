import React from 'react';
import {View,
	Text, 
	StyleSheet, 
Buttons,
TouchableOpacity,
Image,
Switch,
TextInput,
SafeAreaView,
ListView,
ScrollView,
Picker,

}  'react-native';





export default class revision extends Component
OR
class revision
{}


render()
{
	return(
<View>



		)
}
export default revisio;
const revision=()=->{


}