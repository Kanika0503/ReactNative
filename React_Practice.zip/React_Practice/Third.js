
import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TextInput,
  Button,
} from 'react-native';

const Third = ({navigation}) => {

  const [userName1, setUserName1] = useState('');
 const [userName2, setUserName2] = useState('');


  return (
    <SafeAreaView style={{flex: 1}}>
      <View style={styles.container}>
        <Text style={styles.heading}>
          Passing values between screens
        </Text>
        <Text style={styles.textStyle}>
          Please insert your name to pass it to second screen
        </Text>
       
        <TextInput
          value={userName1}
          onChangeText={(username1) => setUserName1(username1)}
          placeholder={'Enter First name'}
          style={styles.inputStyle}
        />
        <TextInput
          value={userName2}
          onChangeText={(username2) => setUserName2(username2)}
          placeholder={'Enter last name'}
          style={styles.inputStyle}
        />
        <Text style={styles.textStyle}>
          Values passed from Second page: {route.params.paramKey4}
        </Text>
              
  
          <Button
          title="Go Next"
          //Button Title
          onPress={() =>
            navigation.navigate('Fourth', {
              paramKey: userName1,
              paramKey1: userName2,
            })
          }
        />

      </View>
       </SafeAreaView>
  );
};

export default Third;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 20,
  },
  heading: {
    fontSize: 25,
    textAlign: 'center',
    marginVertical: 10,
  },
  textStyle: {
    textAlign: 'center',
    fontSize: 16,
    marginVertical: 10,
  },
  inputStyle: {
    width: '80%',
    height: 44,
    padding: 10,
    marginVertical: 10,
    backgroundColor: '#DBDBD6',
  },

});
