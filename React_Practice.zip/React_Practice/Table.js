


import React from 'react';
import { View, StyleSheet } from 'react-native';
import { DataTable } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <DataTable>
        <DataTable.Header>
          <DataTable.Title>Name</DataTable.Title>
          <DataTable.Title>Course</DataTable.Title>
          <DataTable.Title numeric>Roll</DataTable.Title>
        </DataTable.Header>

        <DataTable.Row>
          <DataTable.Cell>Harsh</DataTable.Cell>
          <DataTable.Cell>CAP487</DataTable.Cell>
          <DataTable.Cell numeric>10</DataTable.Cell>
        </DataTable.Row>

        <DataTable.Row>
          <DataTable.Cell>Adrika</DataTable.Cell>
          <DataTable.Cell>CAP488</DataTable.Cell>
                <DataTable.Cell numeric>27</DataTable.Cell>
        </DataTable.Row>

        <DataTable.Row>
          <DataTable.Cell>Mrinmoy</DataTable.Cell>
          <DataTable.Cell>CAP487</DataTable.Cell>
          <DataTable.Cell numeric>19</DataTable.Cell>
        </DataTable.Row>
   <DataTable.Row>
          <DataTable.Cell>xyz</DataTable.Cell>
          <DataTable.Cell>CAP488</DataTable.Cell>
          <DataTable.Cell numeric>29</DataTable.Cell>
        </DataTable.Row>

      </DataTable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingTop: 100,
    paddingHorizontal: 30,
  },
});