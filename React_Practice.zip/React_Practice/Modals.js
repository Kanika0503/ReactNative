import React, {Component} from 'react';  
import {Platform, StyleSheet, Text, View, Button, Modal,Image} from 'react-native';   
export default class App extends Component<Props> {  
  state = {  
    isVisible: false, //state of modal default false  
  }  
  render() {  
    return (  
      <View style = {styles.container}> 
<Modal            
          animationType = {"slide"}  
          transparent = {true}  
          visible = {this.state.isVisible} >  
          
              <View style = {styles.modal}>  
 <Image style={{ width: '100%', height: 200, resizeMode: 'stretch' }}
              source={{ uri: 'https://th.bing.com/th/id/OIP.gnWD7VFpoG6r0TN_LseLWwHaEK?pid=ImgDet&rs=1'}}
              />
             
              
<Button title="Click To Close Modal" onPress = {() => {  
                  this.setState({ isVisible:!this.state.isVisible})}}/>  
          </View>  
        </Modal>  
        <Text> WELCOME </Text>
      <Button
           title="Click To Open Modal"   
           onPress = {() => {this.setState({ isVisible: true})}}  
        />  
      </View>  
    );  
  }  
} 
 
const styles = StyleSheet.create({  
  container: {  
    flex: 1,  
    alignItems: 'center',  
    justifyContent: 'center',  
    backgroundColor: 'green',  
  }, 
 modal: {  
  justifyContent: 'center',  
  alignItems: 'left',   
  backgroundColor : "#00BCD4",   
  height: 300 ,  
  width: '80%',  
  borderRadius:10,  
  borderWidth: 1,  
  borderColor: '#fff',    
  marginTop: 5,  
  marginLeft: 40,  
   
   },  
 
 text: {  
      color: '#3f2949',  
      marginTop: 10  
   }  
}); 
