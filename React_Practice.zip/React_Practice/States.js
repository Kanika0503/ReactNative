import React, { useState } from "react";
import {View,Text} from 'react-native';

export default function state()
{
const[name,setName]=useState('Welcome');
return(
<View>
    <Text>{name}</Text>
    </View>
)
};



/*export default class States extends React.Component
{
state={
name:'BCA Students',
roll:'10'
};
render()
{
return(
<View>
    <Text>{this.state.name}</Text>
    <Text>{this.state.roll}</Text>
</View>
)
};
}*/
