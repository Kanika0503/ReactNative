import React,{Component} from 'react';

class App extends Component {
    state = {
      course:""
    };

    handleChange=(e)=>{
        this.setState({
          course: e.target.value
        })
    }

  render() {
    return (
      <div>
         <form>
            <input type="radio" value="CAP487" id="1"
              onChange={this.handleChange} name="course" />
            <label for="CAP487">react native</label>

            <input type="radio" value="CAP488" id="CAP488"
              onChange={this.handleChange} name="course"/>
            <label for="CAP488">Native script</label>
         
 <input type="radio" value="CAP267" id="CAP267"
              onChange={this.handleChange} name="course"/>
            <label for="CAP267">Data structure</label>
         </form>
         <p>You have selected --> {this.state.course}</p>
      </div>
    );
  }
}

export default App