function Component1(props) {
  return <h2>External component! {props.name}</h2>;
}

export default Component1;
