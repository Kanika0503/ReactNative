import React, { useState } from "react";
import { Switch, StyleSheet, Text, View } from "react-native";

function App() {
  const [isEnabled, setIsEnabled] = useState(false);
  const toggleSwitch = () => {
    setIsEnabled(!isEnabled);
  };
  return (
    <View style={styles.app}>
      <Switch value={isEnabled} onValueChange={toggleSwitch} />
      <Text style={[styles.text, { opacity: isEnabled ? 1 : 0 }]}>
        Working with Dynamic styles
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  app: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "black"
  },
  text: {
    fontSize: 24,
    color: "white"
  }
});

export default App;
