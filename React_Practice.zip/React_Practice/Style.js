import { StyleSheet } from 'react-native';

const styles = StyleSheet.create ({
ViewMain: {
flex: 1,
backgroundColor: '#fefae0',
alignItems: 'center',
justifyContent: 'center',
},
view1:{
backgroundColor:'#d4a373',
height:'40%',
width:'25%',
borderColor:'black',
borderStyle:'solid',
alignContent:'center',
alignItems:'center'
},
view2:{
backgroundColor:'white'

},
text:{
textAlign:'center',
fontSize:'20pt'
},

textInput: {
margin:'10pt',
width:'100pt',
borderWidth: '2pt',
borderColor: 'black',
borderStyle: 'solid',
},
button:{
margin:'5pt',
alignItems: 'center',
justifyContent: 'center',
},
image:{
height:'60',
width:'60'
}
})

export {styles}