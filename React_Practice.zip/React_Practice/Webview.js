import Report,{Component} from 'react';
import {View,WebView} from 'react-native';

const WebViewExample = () => {
return(
<View>
 <WebView source={{uri:"https://www.google.com/"}}/>
 </View>
);
}

export default WebViewExample;