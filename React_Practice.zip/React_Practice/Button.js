import React, { Component } from 'react';  
import {StyleSheet,View, Text,Button} from 'react-native';  

class Button extends Component
{
render(){
return(
  <Button
title="button"
color="blue">
</Button>
  )
}
}